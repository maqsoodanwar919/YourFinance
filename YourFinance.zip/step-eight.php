<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<link rel="icon" href="assets/images/favicon.png" type="image/png">  
	<link type="text/css" rel="stylesheet" href="assets/css/style.css" />
	<link type="text/css" rel="stylesheet" href="assets/css/responsive.css" />  
	<title>Your Finance Claim</title>
 
</head>

<body>
	<div class="main_wrapper">
		<header class="site__header">
			<div class="inner__container">
				<div class="site__header__inner d_flex justify_content_between">
					<div class="site__logo">
						<a href="#">
							<img src="assets/images/logo.png" alt="logo" />
						</a>
					</div>
					<div class="rating__sslsecure d_flex align_center">
						<div class="sslsecure">
							<img src="assets/images/ssl-secure-blue.svg" alt="ssl-secure" />
						</div>
						<div class="rating">
							<img src="assets/images/rating.svg" alt="rating" />
							<p class="text-blue">Rated 5 Stars <span class="text-green">‘Excellent’</span></p>
						</div>
					</div>
				</div>
			</div>
		</header>

		<section class="site__banner step__banner step__eight">
			<div class="inner__container">
				<div class="site__banner__inner">
				    <form class="step__form_wrap" id="main-form">
                        <div class="step__form_inner">
						    <div class="good_news_content more_thing">
                                <h3 class="sec-main-heading text-d-blue">One more thing...</h3>
								<p class="sec-para">Based on the information you’ve given us, please tell us abut your finance agreement(s). this is so we can speed things up on our end</p>
							</div> 
							<div class="car_box_wrap">
								<div class="car_box">
									<div class="head_car">
										<h3 class="sec-main-heading text-d-blue">Car 1</h3>
										<button type="button" class="btn_close">
											<svg xmlns="http://www.w3.org/2000/svg" width="46" height="46" viewBox="0 0 46 46" fill="none">
												<path d="M23.0004 20.2917L32.4879 10.8042L35.1981 13.5144L25.7106 23.0019L35.1981 32.4894L32.486 35.1995L22.9985 25.712L13.5129 35.1995L10.8027 32.4874L20.2902 22.9999L10.8027 13.5124L13.5129 10.8061L23.0004 20.2917Z" fill="#110043"/>
											  </svg>
										</button>
									</div>
									<div class="custom_row"> 
										   <div class="form-group w-33 mrg-rt-28">
											 <label class="sec-label">Enter Registration</label>
											 <input type="text" class="form-control" placeholder="Enter registration" id="enter_registration" name="enter_registration">
										   </div>
										   <div class="form-group w-33 mrg-rt-28">
											<label class="sec-label">Value of Car</label>
											<div class="icon_wrap">
												<input type="text" class="form-control pl-90 name="value_of_car" value="" id="value_of_car" placeholder="Please enter amount">
												<div class="icon_img"><img src="assets/images/pound.svg" alt="pound" /></div>
											</div>
										  </div>
										  <div class="form-group w-33">
											<label class="sec-label">Lender</label>
											<input type="text" class="form-control" placeholder="Enter lender" id="lender" name="lender">
										  </div>

									   </div>  
								</div>
								<div class="add_more_car"> 
                                   <button type="button" class="theme_blue_btn theme_green_btn">+ Add additional car</button>
								</div>
							</div>
							<div class="btn-wrap mt-50 text-center">
								<button type="button" class="theme_green_btn move_next">SUBMIT MY CLAIM</button>
							</div>
						</div>	
					</form>
				</div>
			</div>
		</section> 
	</div>
	   
 
</body>
</html>