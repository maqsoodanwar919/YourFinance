<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<link rel="icon" href="assets/images/favicon.png" type="image/png">  
	<link type="text/css" rel="stylesheet" href="assets/css/style.css" />
	<link type="text/css" rel="stylesheet" href="assets/css/responsive.css" />  
	<title>Your Finance Claim</title>
 
</head>

<body>
	<div class="main_wrapper">
		<header class="site__header">
			<div class="inner__container">
				<div class="site__header__inner d_flex justify_content_between">
					<div class="site__logo">
						<a href="#">
							<img src="assets/images/logo.png" alt="logo" />
						</a>
					</div>
					<div class="rating__sslsecure d_flex align_center">
						<div class="sslsecure">
							<img src="assets/images/ssl-secure-blue.svg" alt="ssl-secure" />
						</div>
						<div class="rating">
							<img src="assets/images/rating.svg" alt="rating" />
							<p class="text-blue">Rated 5 Stars <span class="text-green">‘Excellent’</span></p>
						</div>
					</div>
				</div>
			</div>
		</header>

		<section class="site__banner step__banner step__six">
			<div class="inner__container">
				<div class="site__banner__inner">
				    <form class="step__form_wrap" id="main-form">
                         <div class="step__form_inner">
						     <div class="good_news_content">
                                 <h3 class="sec-main-heading text-d-blue">Good news!</h3>
								 <h5 class="form-label mb-0">You could be in-line to make a claim!</h5>
								 <p class="sec-para">Please enter your personal details below in order to process your claim with us</p>
							 </div>
                            <div class="good_news_form">
							   <div class="custom_row">
								<div class="form-group w-196 mrg-rt-28">
									<select id="title_field" name="title" class="form-control custom_select" required="" >
										<option class="first_option" selected="" value="">Title </option>
										<option value="Mr">Mr</option>
										<option value="Mrs">Mrs</option>
										<option value="Ms">Ms</option>
										<option value="Miss">Miss</option>
										<option value="Dr">Dr</option>
										<option value="Rev">Rev</option>
										<option value="Dame">Dame</option>
										<option value="Lady">Lady</option>
										<option value="Sir">Sir</option>
										<option value="Lord">Lord</option>
									</select>
								   </div>
								   <div class="form-group w-50 mrg-rt-28">
									 <input type="text" class="form-control" placeholder="First Name" id="firstname" name="firstname">
								   </div>
								   <div class="form-group w-50">
									<input type="text" class="form-control" placeholder="Last Name" id="lastname" name="lastname">
								  </div>
							   </div>  
							   <div class="custom_row"> 
								   <div class="form-group w-100 mrg-rt-28">
									 <input type="tel" class="form-control" placeholder="Telephone Number" id="mobile" name="mobile">
								   </div>
								   <div class="form-group w-100">
									<input type="email" class="form-control" placeholder="Email" id="email" name="email">
								  </div>
							   </div>

							   <p class="sec-para mb-10 fw-400">Date of Birth</p>
							   <div class="custom_row">
									<div class="form-group w-100 mrg-rt-28">
										<select class="form-control custom_select" id="dob_day" name="dob_day" required="">
											<option value="" disabled="" selected="" hidden="">DD </option>
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
											<option value="4">4</option>
											<option value="5">5</option>
											<option value="6">6</option>
											<option value="7">7</option>
											<option value="8">8</option>
											<option value="9">9</option>
											<option value="10">10</option>
											<option value="11">11</option>
											<option value="12">12</option>
											<option value="13">13</option>
											<option value="14">14</option>
											<option value="15">15</option>
											<option value="16">16</option>
											<option value="17">17</option>
											<option value="18">18</option>
											<option value="19">19</option>
											<option value="20">20</option>
											<option value="21">21</option>
											<option value="22">22</option>
											<option value="23">23</option>
											<option value="24">24</option>
											<option value="25">25</option>
											<option value="26">26</option>
											<option value="27">27</option>
											<option value="28">28</option>
											<option value="29">29</option>
											<option value="30">30</option>
											<option value="31">31</option>
										</select>
									</div>
									
									<div class="form-group w-100  mrg-rt-28">
										<select class="form-control custom_select" id="dob_month" name="dob_month" required="">
											<option value="" disabled="" selected="" hidden="">MM </option>
											<option value="01" num-days="31">January</option>
											<option value="02" num-days="29">February</option>
											<option value="03" num-days="31">March</option>
											<option value="04" num-days="30">April</option>
											<option value="05" num-days="31">May</option>
											<option value="06" num-days="30">June</option>
											<option value="07" num-days="31">July</option>
											<option value="08" num-days="31">August</option>
											<option value="09" num-days="30">September</option>
											<option value="10" num-days="31">October</option>
											<option value="11" num-days="30">November</option>
											<option value="12" num-days="31">December</option>
										</select>
									</div>
									 <div class="form-group w-100">
										<select class="form-control custom_select" id="dob_year" required="" name="dob_year">
											<option value="" disabled="" selected="" hidden="">YYYY </option>
											<option value="2004">2004</option>
											<option value="2003">2003</option>
											<option value="2002">2002</option>
											<option value="2001">2001</option>
											<option value="2000">2000</option>
											<option value="1999">1999</option>
											<option value="1998">1998</option>
											<option value="1997">1997</option>
											<option value="1996">1996</option>
											<option value="1995">1995</option>
											<option value="1994">1994</option>
											<option value="1993">1993</option>
											<option value="1992">1992</option>
											<option value="1991">1991</option>
											<option value="1990">1990</option>
											<option value="1989">1989</option>
											<option value="1988">1988</option>
											<option value="1987">1987</option>
											<option value="1986">1986</option>
											<option value="1985">1985</option>
											<option value="1984">1984</option>
											<option value="1983">1983</option>
											<option value="1982">1982</option>
											<option value="1981">1981</option>
											<option value="1980">1980</option>
											<option value="1979">1979</option>
											<option value="1978">1978</option>
											<option value="1977">1977</option>
											<option value="1976">1976</option>
											<option value="1975">1975</option>
											<option value="1974">1974</option>
											<option value="1973">1973</option>
											<option value="1972">1972</option>
											<option value="1971">1971</option>
											<option value="1970">1970</option>
											<option value="1969">1969</option>
											<option value="1968">1968</option>
											<option value="1967">1967</option>
											<option value="1966">1966</option>
											<option value="1965">1965</option>
											<option value="1964">1964</option>
											<option value="1963">1963</option>
											<option value="1962">1962</option>
											<option value="1961">1961</option>
											<option value="1960">1960</option>
											<option value="1959">1959</option>
											<option value="1958">1958</option>
											<option value="1957">1957</option>
											<option value="1956">1956</option>
											<option value="1955">1955</option>
											<option value="1954">1954</option>
											<option value="1953">1953</option>
											<option value="1952">1952</option>
											<option value="1951">1951</option>
											<option value="1950">1950</option>
											<option value="1949">1949</option>
											<option value="1948">1948</option>
											<option value="1947">1947</option>
											<option value="1946">1946</option>
											<option value="1945">1945</option>
											<option value="1944">1944</option>
											<option value="1943">1943</option>
											<option value="1942">1942</option>
											<option value="1941">1941</option>
											<option value="1940">1940</option>
											<option value="1939">1939</option>
											<option value="1938">1938</option>
											<option value="1937">1937</option>
											<option value="1936">1936</option>
											<option value="1935">1935</option>
											<option value="1934">1934</option>
											<option value="1933">1933</option>
											<option value="1932">1932</option>
											<option value="1931">1931</option>
											<option value="1930">1930</option>
											<option value="1929">1929</option>
											<option value="1928">1928</option>
											<option value="1927">1927</option>
											<option value="1926">1926</option>
											<option value="1925">1925</option>
											<option value="1924">1924</option>
											<option value="1923">1923</option>
											<option value="1922">1922</option>
											<option value="1921">1921</option>
											<option value="1920">1920</option>
										</select>
									 </div>
                                </div> 

								<div class="post_code_wrap"> 
									<div class="custom_row align_center mt-118">
										<div class="form-group w-100">
											<input type="text" class="form-control" placeholder="Postcode" id="Postcode" name="Postcode">
										</div>
										<div class="form-group postcode_btn w-100">
											<button type="button" class="theme_green_btn theme_blue_btn w-100">Search</button>
										</div> 
									</div>
									<div class="additional_address_wrap">
										<div class="form-group w-100">
											<input type="text" class="form-control" placeholder="Address line 1" id="address_line_1" name="address_line_1">
										</div>
										<div class="form-group w-100">
											<input type="text" class="form-control" placeholder="Address line 2" id="address_line_2" name="address_line_2">
										</div>
										<div class="custom_row"> 
											<div class="form-group w-100 mrg-rt-28">
											  <input type="text" class="form-control" placeholder="Town/City" id="town_city" name="town_city">
											</div>
											<div class="form-group w-100">
											 <input type="text" class="form-control" placeholder="County" id="county" name="county">
										   </div>
										</div>
										<div class="form-group w-100">
											<input type="text" class="form-control" placeholder="Postcode" id="postcode1" name="postcode">
										</div>
									</div>
								</div>

								<div class="iagree_radio check_box form-check mt-50">
									<input type="checkbox" name="i_agree_to_privacy" id="iagree_to_be_terms_conditions" class="agree_boxes">
									<label for="iagree_to_be_terms_conditions"> By proceeding with your claim, you agree to our <a href="">Privacy Policy</a>, <a href="">Terms and Conditions</a> and consent to being contacted by Your Finance Claim, TGG Ltd, or one of our affiliated partners by telephone, email and SMS messaging. You are free to opt-out of this at any time. 
										<span class="error" id="sms_error" style="display: none;">Please accept our Terms &amp; Conditions  </span></label>
								</div>

								<div class="btn-wrap mt-50 text-center">
									<button type="button" class="theme_green_btn move_next">SUBMIT MY CLAIM</button>
								</div>
								<p class="sec-sub-heading text-d-blue average_claim_text text-center fw-400">Average Claim: <b>£4,500</b></p>
							</div>
						 <div>
					</form>
				</div>
			</div>
		</section> 
	</div>
	   
 
</body>
</html>