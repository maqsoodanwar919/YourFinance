<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<link rel="icon" href="assets/images/favicon.png" type="image/png">  
	<link type="text/css" rel="stylesheet" href="assets/css/style.css" />
	<link type="text/css" rel="stylesheet" href="assets/css/responsive.css" />  
	<title>Your Finance Claim</title>
 
</head>

<body>
	<div class="main_wrapper">
		<header class="site__header">
			<div class="inner__container">
				<div class="site__header__inner d_flex justify_content_between">
					<div class="site__logo">
						<a href="#">
							<img src="assets/images/logo.png" alt="logo" />
						</a>
					</div>
					<div class="rating__sslsecure d_flex align_center">
						<div class="sslsecure">
							<img src="assets/images/ssl-secure-blue.svg" alt="ssl-secure" />
						</div>
						<div class="rating">
							<img src="assets/images/rating.svg" alt="rating" />
							<p class="text-blue">Rated 5 Stars <span class="text-green">‘Excellent’</span></p>
						</div>
					</div>
				</div>
			</div>
		</header>

		<section class="site__banner step__banner step__four">
			<div class="inner__container">
				<div class="site__banner__inner">
				    <form class="step__form_wrap" id="main-form">
                         <div class="step__form_inner">
							<div class="progress__wrap">
								<div class="number ">
									<span class="active">4.</span>
								</div>
								<div class="number active">
									<span>3.</span>
								</div>
								<div class="number active">
									<span>2.</span>
								</div>
								<div class="number active">
									<span>1.</span>
								</div>
							</div>
							<div class="form-group">
								<label class="form-label text-center">Did [LenderName] tell you about the commission they received?</label> 
								<div class="btns-wrap custom_radio d-flex">
									<div class="input_wrap mrg-rt-28">
										<input type="radio" class="" value="no" name="commission_received" id="commission_received_no" >
										<label for="commission_received_no"><span>No</span></label>
									</div>
									<div class="input_wrap ">
										<input type="radio" class="" name="commission_received" value="yes" id="commission_received_yes">
										<label class="label-text" for="commission_received_yes"><span>Yes</span></label>
									</div> 
								</div> 
							    <div class="error text-center" style="display: none;">Please confirm commission they received</div>
							</div>  
							<p class="sec-sub-heading text-d-blue average_claim_text text-center fw-400">Average Claim: <b>£4,500</b></p>
						 <div>
					</form>
				</div>
			</div>
		</section> 
	</div>
	   
 
</body>
</html>