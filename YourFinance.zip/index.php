<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<link rel="icon" href="assets/images/favicon.png" type="image/png">  
	<link type="text/css" rel="stylesheet" href="assets/css/style.css" />
	<link type="text/css" rel="stylesheet" href="assets/css/responsive.css" />  
	<title>Your Finance Claim</title>
 
</head>

<body>
	<div class="main_wrapper landing_page">
		<header class="site__header">
			<div class="inner__container">
				<div class="site__header__inner d_flex justify_content_between">
					<div class="site__logo">
						<a href="#">
							<img src="assets/images/logo-white.png" alt="logo" />
						</a>
					</div>
					<div class="rating__sslsecure d_flex align_center">
						<div class="sslsecure">
							<img src="assets/images/ssl-secure.svg" alt="ssl-secure" />
						</div>
						<div class="rating">
							<img src="assets/images/rating.svg" alt="rating" />
							<p class="text-white">Rated 5 Stars <span class="text-green">‘Excellent’</span></p>
						</div>
					</div>
				</div>
			</div>
		</header>

		<section class="site__banner">
			<div class="inner__container">
				<div class="site__banner__inner">
					<div class="banner__content">
						<h1 class="banner-main-heading text-white">Have you had a car on finance before 2021?</h1>
						<p class="sec-sub-heading text-white"><span class="f-weight-light">You could be owed an average of</span> <span class="underline">£4,500 </span>in compensation...</p>
					</div>
					<div class="reg_box_wrap">
						<h2 class="check_for_free text-white">Check for free now here:</h2>
						<form>
						<div class="reg__field_with_actionBtn d_flex">
							<div class="reg__field_wrap">
								<input type="text" class="car_registation_number" placeholder="ENTER REG" id="registration_number" name="car_reg" value="" />
								<div class="gb">
									<img src="assets/images/gb.png" alt="gb">
								</div>
							</div>
							<div class="btn-wrap">
								<button type="button" class="theme_green_btn move_next">START YOUR FREE CHECK</button>
							</div>
						</div>
						</form>
					</div>
				</div>
			</div>
		</section>

		<section class="services">
			<div class="inner__container">
				<div class="row">
					<div class="col-xl-3">
						<div class="service_box">
							<div class="ico">
								<svg xmlns="http://www.w3.org/2000/svg" width="65" height="62" viewBox="0 0 65 62" fill="none">
									<path opacity="0.95" d="M32.4675 0.181641C14.5275 0.181641 0 13.998 0 31.0218C0 48.0456 14.5275 61.862 32.4675 61.862C50.44 61.862 65 48.0456 65 31.0218C65 13.998 50.44 0.181641 32.4675 0.181641ZM45.5 43.3579C45.1993 43.6438 44.8422 43.8707 44.449 44.0254C44.0558 44.1802 43.6344 44.2598 43.2087 44.2598C42.7831 44.2598 42.3617 44.1802 41.9685 44.0254C41.5753 43.8707 41.2182 43.6438 40.9175 43.3579L30.225 33.2115C29.9179 32.9259 29.6737 32.5852 29.5062 32.2094C29.3389 31.8335 29.2518 31.4299 29.25 31.0218V18.6858C29.25 16.9895 30.7125 15.6017 32.5 15.6017C34.2875 15.6017 35.75 16.9895 35.75 18.6858V29.7574L45.5 39.0094C46.7675 40.2122 46.7675 42.1552 45.5 43.3579Z" fill="white"/>
								</svg>
							</div>
							<p>Returns results in under a minute</p>
						</div>
					</div>
					<div class="col-xl-3">
						<div class="service_box">
							<div class="ico">
								<img src="assets/images/shake-hand.svg" alt="shake-hand" />
							</div>
							<p>Can’t claim? Don’t pay us a penny</p>
						</div>
					</div>
					<div class="col-xl-3">
						<div class="service_box">
							<div class="ico">
								<img src="assets/images/globe.svg" alt="globe" />
							</div>
							<p>100% online process</p>
						</div>
					</div>
					<div class="col-xl-3">
						<div class="service_box">
							<div class="ico">
								<svg xmlns="http://www.w3.org/2000/svg" width="48" height="63" viewBox="0 0 48 63" fill="none">
									<path fill-rule="evenodd" clip-rule="evenodd" d="M10.4167 0.875H32.625L48 15.1927V51.7822C48 52.6261 47.64 53.4354 46.9992 54.032C46.3586 54.6287 45.4895 54.964 44.5833 54.964H10.4167C9.51051 54.964 8.64146 54.6287 8.00071 54.032C7.35996 53.4354 7 52.6261 7 51.7822V4.0567C7 3.21286 7.35996 2.40359 8.00071 1.8069C8.64146 1.21021 9.51051 0.875 10.4167 0.875ZM42.875 15.1927L32.625 5.64756V13.6018C32.625 14.0238 32.805 14.4284 33.1254 14.7267C33.4457 15.025 33.8802 15.1927 34.3334 15.1927H42.875ZM19.4589 25.2039C19.7793 24.9057 20.2137 24.7381 20.6666 24.7381C21.1197 24.7381 21.5541 24.9057 21.8745 25.2039L27.5 30.4425L33.1255 25.2039C33.4478 24.9141 33.8793 24.7538 34.3272 24.7574C34.7751 24.761 35.2036 24.9283 35.5203 25.2233C35.837 25.5182 36.0167 25.9172 36.0206 26.3343C36.0245 26.7514 35.8523 27.1533 35.5411 27.4534L29.9156 32.692L35.5411 37.9307C35.8523 38.2308 36.0245 38.6326 36.0206 39.0497C36.0167 39.4668 35.837 39.8658 35.5203 40.1607C35.2036 40.4558 34.7751 40.623 34.3272 40.6267C33.8793 40.6303 33.4478 40.4699 33.1255 40.1801L27.5 34.9415L21.8745 40.1801C21.5522 40.4699 21.1207 40.6303 20.6728 40.6267C20.2249 40.623 19.7964 40.4558 19.4797 40.1607C19.163 39.8658 18.9833 39.4668 18.9794 39.0497C18.9755 38.6326 19.1477 38.2308 19.4589 37.9307L25.0844 32.692L19.4589 27.4534C19.1386 27.155 18.9587 26.7505 18.9587 26.3287C18.9587 25.9068 19.1386 25.5022 19.4589 25.2039Z" fill="white"/>
									<path d="M3.5 9.41504H0V54.2519C0 56.4541 0.921872 58.566 2.56281 60.1231C4.20375 61.6803 6.42936 62.5551 8.74999 62.5551H42V59.2338H8.74999C7.35761 59.2338 6.02225 58.7089 5.03769 57.7747C4.05312 56.8403 3.5 55.5732 3.5 54.2519V9.41504Z" fill="white"/>
								</svg>
							</div>
							<p>No additional documents</p>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!-- mis_sold_pcp -->
		<section class="mis_sold_pcp">
			<div class="theme_container mis_sold_pcp_inner">
				<div class="mis_sold_pcp_content pr-90">
					<div class="innre">
						<h2 class="f_forma sec-main-heading mb-14 text-blue">Have you ever wondered about the concept of 'mis-sold' PCP finance?</h2>
					<p class="sec-para text-blue">Well, it turns out that a significant number of UK drivers might be owed financial compensation. The FCA's investigation uncovered instances where individuals were being charged excessively in their monthly finance payments.
					</p>
					</div>
				</div> 
				<div class="you_could_qualify after_line pl-90">
					<h3 class="f_forma sec-sub-heading mb-20 text-blue">You could qualify if:</h3>
					<ul class="custom_list">
						<li class="sec-para text-blue f_hel">our lender didn't inform you about the commission fees associated with your agreement.</li>
						<li class="sec-para text-blue f_hel">The interest rate on your agreement was inflated due to these high commission fees.</li>
						<li class="sec-para text-blue f_hel">Your lender failed to provide a clear explanation of the complete terms and workings of your car finance loan. It's essential to be aware of these details.</li> 
					</ul>
					<div class="btn_wrap mt-40">
						<button type="button" class="theme_green_btn ">START YOUR FREE CHECK</button>
					</div>
				</div>
			</div> 
		</section>

		<!-- how_do_eligible -->
		<section class="how_do_eligible">
			<div class="how_do_eligible_inner">
			    <h4 class="sec-main-heading  text-white text-center">How do I know I’m eligible?</h4>
				<div class="row how_do_eligible_item"> 
					<div class="col-xl-3 how_do_eligible_card">
						<span class="number">1.</span>
						<p class="sec-para text-white">Simply fill in our quick, easy-to-complete form</p>
					</div>
					<div class="col-xl-3 how_do_eligible_card">
						<span class="number">2.</span>
						<p class="sec-para text-white">Our specialist team will review your case</p>
					</div>
					<div class="col-xl-3 how_do_eligible_card">
						<span class="number">3.</span>
						<p class="sec-para text-white">Find out if your claim is successful, and await you payment</p>
					</div>
				</div>
				<button type="button" class="theme_green_btn mt-40 desktop-none mobile-block">START YOUR FREE CHECK</button>
			</div> 
		</section>

		<section class="frequently_asked_wrap">
			<div class="theme_container frequently_asked_questions_inner"> 
				<div class="frequently_asked_content pr-70">
					<h2 class="f_forma sec-main-heading mb-14 text-blue">Frequently Asked Questions</h2>
					<button type="button" class="theme_green_btn mt-40 desktop-block mobile-none">START YOUR FREE CHECK</button>
				</div>   
				<div class="frequently_asked_questions after_line pl-70">
					<div class="card">
						<div class="card-header" onclick="toggleCard(this)"> 
							<button class="btn sec-sub-heading text-blue">
								<div class="rotate-svg">
									<div class=circle>
										<div class='horizontal-plus'></div>
										<div class='vertical-plus'></div>
									</div>
								</div> 
								Just how easy is it for me to claim back?
							</button> 
						</div>
						<div class="card-body">
							<div class="card-body-inner">
								<p class="sec-para text-blue">It has never been simpler to find out if you're due compensation on your current and old finance agreements.</p>
								<p class="sec-para text-blue">Start here by  <b><a href="" class="text-d-blue">filling out our free online form</a></b> today!</p>
							</div>
						</div>
					</div> 
					<div class="card">
						<div class="card-header" onclick="toggleCard(this)"> 
							<button class="btn sec-sub-heading text-blue">
								<div class="rotate-svg">
									<div class=circle>
										<div class='horizontal-plus'></div>
										<div class='vertical-plus'></div>
									</div>
								</div>
								How do I know if I’m entitled to compensation?
							</button> 
						</div>
						<div class="card-body">
							<div class="card-body-inner">
								<p class="sec-para text-blue">If you took out some sort of finance agreement, like PCP agreement or HP policy in the last ten years, then you could be a victim of mis-selling and eligible to make a claim.</p>
								<p class="sec-para text-blue">Find out if you could be due compensation today by <b><a href="" class="text-d-blue">filling out our free online form</a></b> now!</p>
							</div>
						</div>
					</div> 

					<div class="card">
						<div class="card-header" onclick="toggleCard(this)"> 
							<button class="btn sec-sub-heading text-blue">
								<div class="rotate-svg">
									<div class=circle>
										<div class='horizontal-plus'></div>
										<div class='vertical-plus'></div>
									</div>
								</div> 
								What criteria must I meet?
							</button> 
						</div>
						<div class="card-body">
							<div class="card-body-inner">
								<p class="sec-para text-blue">In order to initially qualify for making a claim through us, any of the following must have taken place:</p> 
								<ul class="custom_list">
									<li class="sec-para text-blue f_hel">Your lender failed to alert you that they would be profiting from your policy’s commission payments.</li>
									<li class="sec-para text-blue f_hel">You did know about the commissions, but weren’t fully aware about just how much money your lender was making from them.</li>
									<li class="sec-para text-blue f_hel">The finer details of your finance and vehicle loans were not properly explained to you.</li>
									<li class="sec-para text-blue f_hel">You were being charged higher-than-normal interest rates because of the lender’s commissions arrangement.</li> 
								</ul> 
								<p class="sec-para text-blue">If this criteria applies to you, then see if you could <b><a href="" class="text-d-blue">make a claim</a></b> by checking out our free, fully online form here.</p> 
							</div>
						</div>
					</div> 
					<div class="card border-none">
						<div class="card-header" onclick="toggleCard(this)"> 
							<button class="btn sec-sub-heading text-blue">
								<div class="rotate-svg">
									<div class=circle>
										<div class='horizontal-plus'></div>
										<div class='vertical-plus'></div>
									</div>
								</div> 
								Does it matter if I had a PCP agreement? Could I qualify with a HP loan
							</button> 
						</div>
						<div class="card-body">
							<div class="card-body-inner">
								<p class="sec-para text-blue">There’s no need to worry if you didn’t take out a PCP finance agreement, as we accept claims based off a wide range of vehicle finance agreements. This includes HP loans!</p> 
								<p class="sec-para text-blue">Start your claim today by <b><a href="" class="text-d-blue">filling out our online form </a></b> now. </p> 
							</div>
						</div>
					</div> 
					<button type="button" class="theme_green_btn mt-40 desktop-none mobile-block">START YOUR FREE CHECK</button>
				</div> 
			</div> 
		</section>
 

		<footer class=" footer ">
			<div class="theme_container footer-text py-80 text-center">
				<p class="sec-para "> This site is owned and operated by Olton Alexander Limited which is registered in England and Wales. Registered number: 07652082. Registered office: Calcutt Court, Calcutt, Swindon, England, SN6 6JR. Olton Alexander Limited is authorised and regulated by the Financial Conduct Authority in respect of regulated claims management activity. FRN: 833941. Information Commissioner's Office registration number ZB559651.</p>
				<ul class="footer_links">
					<li>  <a target="_blank" href="">Terms &amp; Conditions</a>  </li>
					<li> <a target="_blank" href="">Privacy Policy</a> </li>  
				</ul>
			</div>
		</footer>
	</div>
	  

	<script src="assets/js/custom.js"></script>
 
</body>
</html>