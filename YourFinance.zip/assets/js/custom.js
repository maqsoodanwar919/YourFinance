function toggleCard(card) {
    var cardBody = card.nextElementSibling;
    var svg = card.querySelector('.rotate-svg');
    // Close all other cards
    var allCards = document.querySelectorAll('.card-body');
    allCards.forEach(function (otherCard) {
        if (otherCard !== cardBody) {
            otherCard.style.maxHeight = null;
            otherCard.previousElementSibling.querySelector('.rotate-svg').classList.remove('rotate');
        }
    });
    if (cardBody.style.maxHeight === '0px' || cardBody.style.maxHeight === '') {
        cardBody.style.maxHeight = cardBody.scrollHeight + "px";
        svg.classList.add('rotate');
    } else {
        cardBody.style.maxHeight = null;
        svg.classList.remove('rotate');
    }
}



 
const registrationInput = document.getElementById('registration_number');
const startCheckBtn = document.getElementById('start_check_btn');
const registrationForm = document.getElementById('registration_form');

function validateRegistrationNumber() {
    const regExp = /^[A-Za-z]{2}\d{2}\s?[A-Za-z]{3}$/;
    const isValid = regExp.test(registrationInput.value.trim());
    startCheckBtn.disabled = !isValid;
}

registrationInput.addEventListener('input', validateRegistrationNumber);

startCheckBtn.addEventListener('click', function() {
    if (registrationInput.value.trim() === '') {
        // If registration number is empty, submit the form
        registrationForm.submit();
    } else {
        // If registration number is not empty, proceed with other action
        // You can replace the code below with the logic to navigate to the next page
        alert('Proceeding to next page...');
        // Here you can implement code to navigate to the next page
    }
});


function myFunction() {
    document.getElementById("demo").innerHTML = "Hello World";
  }


 