<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<link rel="icon" href="assets/images/favicon.png" type="image/png">  
	<link type="text/css" rel="stylesheet" href="assets/css/style.css" />
	<link type="text/css" rel="stylesheet" href="assets/css/responsive.css" />  
	<title>Your Finance Claim</title>
 
</head>

<body>
	<div class="main_wrapper">
		<header class="site__header">
			<div class="inner__container">
				<div class="site__header__inner d_flex justify_content_between">
					<div class="site__logo">
						<a href="#">
							<img src="assets/images/logo.png" alt="logo" />
						</a>
					</div>
					<div class="rating__sslsecure d_flex align_center">
						<div class="sslsecure">
							<img src="assets/images/ssl-secure-blue.svg" alt="ssl-secure" />
						</div>
						<div class="rating">
							<img src="assets/images/rating.svg" alt="rating" />
							<p class="text-blue">Rated 5 Stars <span class="text-green">‘Excellent’</span></p>
						</div>
					</div>
				</div>
			</div>
		</header>

		<section class="site__banner step__banner step__eight">
			<div class="inner__container">
				<div class="site__banner__inner">
				    <form class="step__form_wrap" id="main-form">
                        <div class="step__form_inner thanku_main">
						    <div class="good_news_content more_thing">
								<h1 class="banner-main-heading m-auto">Thank you, [Name]!</h1>
                                <h2 class="thank-u-sub-heading text-d-blue m-auto">Our specialist team has now received your claim for compensation.</h3>
								<p class="sec-para mt-25">We will review your information and one of our advisers will be in touch soon to discuss what will happen next.</p>
							</div> 
							<div class="upload_id_content text-center mt-95">
								<h3 class="sec-main-heading text-d-blue">Fast track your claim</h3>
								<h4 class="thank-u-sub-heading text-d-blue m-auto">by uploading proof of identification (ID)</h4>
								<div class="good_news_content">
									<p class="sec-para mt-25">e.g a photo of your passport or drivers license</p>
								</div>
								<div class="upload_image">
									<div class="fileupload_thanku">
										<input class="" type="hidden" name="hidden_lead_id" id="hidden_lead_id" value="">
										<div class="fileupload-inner">
											<input class="upload" type="file" name="file" id="uploadfile" accept=".jpg, .jpeg, .png">
											<div class="click_to_upload">
												<img src="assets/images/image-icon.svg" alt="image-icon">
												<p id="uploadclick">Click to upload</p>
											</div>
										</div>
										<p id="file_name" style="display: none;color:#77bc0e;"></p>
									</div>
									<div id="file_size" style="display:none;">
										<label class="error" style="color:red;">File size should be less than 6MB.</label>
									</div>
									<p id="empty_file_error" style="display:none; color:red;">Please select a file to upload</p>

									<div class="btn-wrap mt-50 text-center">
										<button type="submit" class="theme_green_btn move_next">SUBMIT</button>
									</div>
								</div>
							</div>
						</div>	
					</form>
				</div>
			</div>
		</section> 
	</div>
	   
 
</body>
</html>